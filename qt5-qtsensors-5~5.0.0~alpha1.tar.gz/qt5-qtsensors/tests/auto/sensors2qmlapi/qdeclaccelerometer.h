/****************************************************************************
**
** Copyright (C) 2012 Nokia Corporation and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/
**
** This file is part of the QtSensors module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL$
** GNU Lesser General Public License Usage
** This file may be used under the terms of the GNU Lesser General Public
** License version 2.1 as published by the Free Software Foundation and
** appearing in the file LICENSE.LGPL included in the packaging of this
** file. Please review the following information to ensure the GNU Lesser
** General Public License version 2.1 requirements will be met:
** http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** In addition, as a special exception, Nokia gives you certain additional
** rights. These rights are described in the Nokia Qt LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU General
** Public License version 3.0 as published by the Free Software Foundation
** and appearing in the file LICENSE.GPL included in the packaging of this
** file. Please review the following information to ensure the GNU General
** Public License version 3.0 requirements will be met:
** http://www.gnu.org/copyleft/gpl.html.
**
** Other Usage
** Alternatively, this file may be used in accordance with the terms and
** conditions contained in a signed written agreement between you and Nokia.
**
**
**
**
**
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef QDECLACCELEROMETER_H
#define QDECLACCELEROMETER_H

#include <qsensorbackend.h>
#include "qaccelerometer.h"

class QDeclAccelerometer : public QSensorBackend
{
    Q_OBJECT
public:
    explicit QDeclAccelerometer(QSensor *sensor)
        : QSensorBackend(sensor)
        , _active(false)
        , _sensor(sensor)
    {
    }
    virtual ~QDeclAccelerometer() {}

    void start() { _active = true; }
    void stop()
    {
        _sensor->stop();
        _active = false;
    }
    bool isActive() { return _active; }

    void test(qreal x, qreal y, qreal z)
    {
        if (sensor()->filters().count() > 0){
            QAccelerometerFilter* af = (QAccelerometerFilter*)sensor()->filters().at(0);
            reader.setX(x);
            reader.setY(y);
            reader.setZ(z);
            af->filter(&reader);
        }
    }
private:
    bool _active;
    QSensor* _sensor;
    QAccelerometerReading reader;
};
#endif

